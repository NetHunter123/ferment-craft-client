import React from 'react';
import styles from './header-decor.module.css';

const HeaderDecor = () => {
	return (
		<div className={styles.decor_root}>
			<div className={styles.decor__wrap}>
				<div className={`${styles.decor__element}`}></div>
				<div className={`${styles.decor__element}`}></div>
				<div className={`${styles.decor__element}`}></div>
			</div>
		</div>
	);
};

export default HeaderDecor;
