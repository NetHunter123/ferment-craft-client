import React from 'react';
import styles from "./nav.module.css"
import Link from "next/link";
import { FaChevronDown } from "react-icons/fa6";

const Nav = () => {
	return (
			<nav className={styles.nav}>
			<ul className={styles.nav__list}>
				<li className={styles.nav__item}>
					<Link href="/partners" className={styles.nav__link}>Партнерам</Link></li>
				<li className={styles.nav__item}>
					<Link href="/prices" className={styles.nav__link}>Ціни</Link></li>
				<li className={styles.nav__item}>
					<Link href="/order" className={styles.nav__link}>Замовлення продукції <FaChevronDown/></Link></li>
			</ul>
		</nav>
	);
};

export default Nav;
