import React from 'react';
import styles from './logo.module.css';

const Logo = () => {
	return (
		<a className={styles.logo__root}>
			<span>Ferment</span> Craft
		</a>
	);
};

export default Logo;
